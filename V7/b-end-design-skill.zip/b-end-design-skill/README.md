# B 端设计 Skill

通用 B 端后台管理系统设计规范，基于 Ant Design 体系整理。
导入 Claude / Cursor / Copilot 后即可使用，替换品牌色全局生效。

## 目录结构

```
skill/
├── SKILL.md          # 主文档入口（导入 AI 工具的核心文件）
├── tokens/           # 设计变量（色彩、字体、间距、圆角阴影）
├── components/       # 组件规范（按钮、输入框、表格、表单、状态）
├── patterns/         # 页面设计模式（列表页、详情页、表单页、看板）
├── templates/        # 业务场景模板（审批流、权限、消息、异常页）
├── examples/         # 可运行 HTML 模板（列表、表单、详情）
├── rules/            # 验收 Checklist
├── prompts/          # 场景化 Prompt
└── scripts/          # 验证脚本
```

## 快速开始

1. 将 `skill/` 文件夹导入 AI 工具
2. 复制 `skill/prompts/base.md` 中的人设激活 Skill
3. 修改 `skill/tokens/colors.json` 替换品牌色
4. 在 `skill/examples/` 中预览三个 HTML 页面模板

## 定制方式

- **换品牌色**：修改 `tokens/colors.json` 中 `brand.primary` 的值
- **加业务模板**：在 `templates/` 中按现有格式新增文件
- **加历史案例**：在 `examples/` 中新建文件夹，放截图和说明

